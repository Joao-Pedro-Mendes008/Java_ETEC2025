package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import projeto_java.ConnectionFactory;
import modelo.Cliente;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author joao_24716
 */
public class ClienteDAO {
    private Connection con;
    public ClienteDAO() {
        this.con = new ConnectionFactory().getConnection();
    }
    
    public void adiciona(Cliente c) {
        String sql = "insert into cliente" 
                + "nome, idade, salario" 
                + "values (?, ?, ?)";
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, c.getNome());
            stmt.setInt(2, c.getIdade());
            stmt.setDouble(3, c.getSalario());
            stmt.execute();
            stmt.close();
        } catch (SQLException e){
            throw new RuntimeException(e);
        }
    }
}
