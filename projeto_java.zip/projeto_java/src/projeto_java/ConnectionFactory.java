package projeto_java;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author joao_24716
 */
public class ConnectionFactory {

    public Connection getConnection() {
        System.out.println("Conectado ao Banco de Dados");
        try {
            return DriverManager.getConnection("jdbc:mysql://localhost:/projeto_java", "root", "12345678");

        } catch (SQLException e) {
            throw new RuntimeException(e);                  
        }
    }
    
    public static void main (String[] args){
        new ConnectionFactory().getConnection();
        System.out.println("Conexão criada com sucesso");
    }
}
